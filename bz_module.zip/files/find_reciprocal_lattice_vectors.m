function [g1,g2,g3] = find_reciprocal_lattice_vectors(r1,r2,r3)
volume = dot(r1,cross(r2,r3));
g1 = 2*pi*(cross(r2,r3)/volume);
g2 = 2*pi*(cross(r3,r1)/volume);
g3 = 2*pi*(cross(r1,r2)/volume);
end

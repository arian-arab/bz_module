function ret = cycl(in, c)
    ret = mod(in-1,c)+1;
end
function plot_kPath(g1,g2,g3)
answer = inputdlg({'Photon Energy (eV):','Inner Potential (eV):','Work Function (eV):','Detector Span (Degrees):','Theta','Phi','Titl'},'Input',[1 50],{'200','10','0','-10:0.1:10','0','0','0'});
if isempty(answer)~=1
    photon_energy = str2double(answer{1});
    inner_potential = str2double(answer{2});
    work_function = str2double(answer{3});
    detector_angles = eval(answer{4});
    theta = str2double(answer{5});
    phi = str2double(answer{6});
    tilt = str2double(answer{7});     
    G=[g1;g2;g3]';       
    r=0.5124*sqrt(photon_energy-work_function);
    kPathCartesian(1,:)=r*sind(detector_angles);
    kPathCartesian(2,:)=0;
    kPathCartesian(3,:)=0.5124*sqrt(((photon_energy-work_function).*cosd(detector_angles).*cosd(detector_angles))+inner_potential);
    k_path=rotationmatrix(phi,[0 0 1])*rotationmatrix(-tilt,[1 0 0])*rotationmatrix(-(theta),[0 1 0])*kPathCartesian;
    Diff=k_path(:,end)-k_path(:,1);
    kPathLength=sqrt(Diff(1).^2+Diff(2).^2+Diff(3).^2);
    
    figure()
    set(gcf,'name','BZ','color','w','units','normalized','position',[0.2 0.1 0.4 0.8])
    faces=calculate_BZ(G);       
    draw_BZ_faces(faces,[0 0 0],'b');
    axis equal
    axis off
    view(-160,10)
    
    figure()
    set(gcf,'name','BZ k_Path ARPES','color','w','units','normalized','position',[0.2 0.1 0.4 0.8])
    hold on
    plot3(k_path(1,:),k_path(2,:),k_path(3,:),'r','linewidth',2)
    plot_cone(k_path)
    plot_sample(theta,tilt,phi)
    
    %--------DRAW BZ---------------%    
    draw_BZ_faces(faces,[0 0 0],'b');
    draw_faces(faces)
    draw_bz_along_kpath(faces,k_path,kPathLength,g1,g2,g3)
    draw_k_path_inbetween(faces,k_path,work_function,inner_potential,detector_angles,phi,tilt,theta)
    %--------DRAW BZ---------------%     
    
    mArrow3([0 0 0],[0 0 kPathLength/5],'color','k','stemWidth',kPathLength/200);
    mArrow3([0 0 0],[kPathLength/5 0 0],'color','k','stemWidth',kPathLength/200);
    mArrow3([0 0 0],[0 kPathLength/5 0],'color','k','stemWidth',kPathLength/200);
    text(kPathLength/(4.5),0,0,'X')
    text(0,kPathLength/(4.5),0,'Y')
    text(0,0,kPathLength/(4.5),'Z')
    axis equal tight
    set(gca,'box','on','boxstyle','full','TickLabelInterpreter','latex','fontsize',18)
    xlabel('$k_{x} (\AA^{-1}) $','interpreter','latex','fontsize',18)
    ylabel('$k_{y} (\AA^{-1}) $','interpreter','latex','fontsize',18)
    zlabel('$k_{z} (\AA^{-1}) $','interpreter','latex','fontsize',18)
    view(-160,10)
else
end
end

function plot_sample(theta,tilt,phi)
line1(1,:)=-0.5:0.1:0.5;line1(2,:)=0.5;line1(3,:)=0;
line2(1,:)=-0.5:0.1:0.5;line2(2,:)=-0.5;line2(3,:)=0;
line3(2,:)=-0.5:0.1:0.5;line3(1,:)=-0.5;line3(3,:)=0;
line4(2,:)=-0.5:0.1:0.5;line4(1,:)=0.5;line4(3,:)=0;
line1rot=rotationmatrix(phi,[0 0 1])*rotationmatrix(tilt,[1 0 0])*rotationmatrix(theta,[0 1 0])*line1;
line2rot=rotationmatrix(phi,[0 0 1])*rotationmatrix(tilt,[1 0 0])*rotationmatrix(theta,[0 1 0])*line2;
line3rot=rotationmatrix(phi,[0 0 1])*rotationmatrix(tilt,[1 0 0])*rotationmatrix(theta,[0 1 0])*line3;
line4rot=rotationmatrix(phi,[0 0 1])*rotationmatrix(tilt,[1 0 0])*rotationmatrix(theta,[0 1 0])*line4;
plot3(line1rot(1,:),line1rot(2,:),line1rot(3,:),'r','linewidth',1.5)
plot3(line2rot(1,:),line2rot(2,:),line2rot(3,:),'r','linewidth',1.5)
plot3(line3rot(1,:),line3rot(2,:),line3rot(3,:),'r','linewidth',1.5)
plot3(line4rot(1,:),line4rot(2,:),line4rot(3,:),'r','linewidth',1.5)
end

function plot_cone(k_path)
m = [1 size(k_path,2)];
for i=1:2
    plot3([0 k_path(1,m(i))],[0 k_path(2,m(i))],[0 k_path(3,m(i))],'r','linewidth',2)
end
end

function draw_faces(faces)
hold on
for i = 1:length(faces)
    fill3(faces(i).corners(:,1),faces(i).corners(:,2),faces(i).corners(:,3),'b','facealpha',0.1)
end
end

function draw_k_path_inbetween(faces,k_path,work_function,inner_potential,detector_angles,phi,tilt,theta)
z_max=max(k_path(3,:));
for i = 1:length(faces)
    gamma_to_gamma_length(i) = max(faces(i).corners(:,3));    
end
gamma_to_gamma_length = 2*max(gamma_to_gamma_length);

for i = 1:floor(z_max/(gamma_to_gamma_length))
    hv(i) = ((gamma_to_gamma_length*i)/0.5124).^2+work_function-inner_potential;
    text(0,0,gamma_to_gamma_length*i,['$\Gamma$','=        ',num2str(hv(i))],'interpreter','latex','fontsize',16,'color','k')
end

for i = 1:length(hv)
    if hv(i)>0
        r=0.5124*sqrt(hv(i)-work_function);
        kPathCartesian(1,:)=r*sind(detector_angles);
        kPathCartesian(2,:)=0;
        kPathCartesian(3,:)=0.5124*sqrt(((hv(i)-work_function).*cosd(detector_angles).*cosd(detector_angles))+inner_potential);
        k_path=rotationmatrix(phi,[0 0 1])*rotationmatrix(-tilt,[1 0 0])*rotationmatrix(-(theta),[0 1 0])*kPathCartesian;
        plot3(k_path(1,:),k_path(2,:),k_path(3,:),'k','linewidth',1.5)
    end
end

for i = 1:floor(z_max/(gamma_to_gamma_length))
    hv(i) = ((gamma_to_gamma_length*i-gamma_to_gamma_length/2)/0.5124).^2+work_function-inner_potential;
    text(0,0,gamma_to_gamma_length*i-gamma_to_gamma_length/2,['$Z$','=        ',num2str(hv(i))],'interpreter','latex','fontsize',16,'color','m')
end

for i = 1:length(hv)
    if hv(i)>0
        r=0.5124*sqrt(hv(i)-work_function);
        kPathCartesian(1,:)=r*sind(detector_angles);
        kPathCartesian(2,:)=0;
        kPathCartesian(3,:)=0.5124*sqrt(((hv(i)-work_function).*cosd(detector_angles).*cosd(detector_angles))+inner_potential);
        k_path=rotationmatrix(phi,[0 0 1])*rotationmatrix(-tilt,[1 0 0])*rotationmatrix(-(theta),[0 1 0])*kPathCartesian;
        plot3(k_path(1,:),k_path(2,:),k_path(3,:),'m','linewidth',1.5)
    end
end
end

function draw_bz_along_kpath(faces,k_path,kPathLength,g1,g2,g3)  
G=[g1;g2;g3]';   
for i = 1:length(faces)
    z_step(i) = max(faces(i).corners(:,3));
end
z_step = 2*max(z_step);
z_max=max(k_path(3,:));
for i=1:ceil((z_max-z_step/2)/z_step)
    sols=ProblemSolverBZ(G',[0 0 i*z_step]);
    draw_BZ_faces(faces,sols,'k','--');
end
text(0,0,z_max+z_step/2,strcat(num2str(ceil((z_max-z_step/2)/z_step)),'th BZ'),'color','r','interpreter','latex','fontsize',18)

Num=floor(kPathLength/(min([norm(g1),norm(g2),norm(g3)])/2));
Step=round(size(k_path,2)/Num);
sols=ProblemSolverBZ(G',k_path(:,1)');
draw_BZ_faces(faces,sols,'b');
for i=2:Num+1
    solsm=sols;
    k=Step*(i-1);
    if k<size(k_path,2)
        P=k_path(:,k)';
    else
        P=k_path(:,end)';
    end
    sols=ProblemSolverBZ(G',P);
    if solsm(1)==sols(1) && solsm(2)==sols(2) && solsm(3)==sols(3)
        continue
    else
        draw_BZ_faces(faces,sols,'b','-');
    end
end
end
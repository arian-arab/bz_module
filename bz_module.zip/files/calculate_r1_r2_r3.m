function [volume,r1,r2,r3]=calculate_r1_r2_r3(a,b,c,alpha,beta,gamma)
angle_proper = (90-gamma)/2;
a_x = a*cosd(angle_proper);
a_y = a*sind(angle_proper);
a_z = 0;
b_x = b*cosd(gamma+angle_proper);
b_y = b*sind(gamma+angle_proper);
b_z = 0;

c_y = (b*c*cosd(alpha)-b_x*a*c*cosd(beta)/a_x)/(b_y-b_x*a_y/a_x);
c_x = (a*c*cosd(beta)-a_y*c_y)/a_x;
c_z = sqrt(c^2-c_x^2-c_y^2);

r1 = [a_x,a_y,a_z];
r2 = [b_x,b_y,b_z];
r3 = [c_x,c_y,c_z];
volume = dot(r1,cross(r2,r3));

% a_x = a;
% a_y = 0;
% a_z = 0;
% b_x = b*cosd(gamma);
% b_y = b*sind(gamma);
% b_z = 0;
% c_x = c*cosd(beta);
% c_y = (b*c*cosd(alpha)-b_x*c_x)/b_y;
% c_z = sqrt(c^2-c_x^2-c_y^2);
% 
% r1 = [a_x,a_y,a_z];
% r2 = [b_x,b_y,b_z];
% r3 = [c_x,c_y,c_z];
% volume = dot(r1,cross(r2,r3));


% r1= [a 0 0];
% r2 = [b*cosd(gamma) b*sind(gamma) 0];
% r3 = [c*cosd(beta) c*((cosd(alpha)-cosd(beta)*cosd(gamma))/sind(gamma)) c*sqrt(1-cosd(beta)*cosd(beta)-((cosd(alpha)-cosd(beta)*cosd(gamma))/sind(gamma)).^2)];
% volume=a*b*c*sqrt(1+2*cosd(alpha)*cosd(beta)*cosd(gamma)-cosd(alpha)*cosd(alpha)-cosd(beta)*cosd(beta)*cosd(gamma)*cosd(gamma));
end
function [r1,r2,r3,volume,g1,g2,g3] = BZ_module_find_g1_g2_g3(a,b,c,alpha,beta,gamma,system)
if system == 1
    r1 = [a,0,0];
    r2 = [0,a,0];
    r3 = [0,0,a];
end
if system == 2
    r1 = [-a/2,a/2,a/2];
    r2 = [a/2,-a/2,a/2];
    r3 = [a/2,a/2,-a/2];
end
if system == 3
    r1 = [0,a/2,a/2];
    r2 = [a/2,0,a/2];
    r3 = [a/2,a/2,0];
end
if system == 4
    r1 = [a/2,-a*sqrt(3)/2,0];
    r2 = [a/2,a*sqrt(3)/2,0];
    r3 = [0,0,c];
end
if system == 5
    r1 = [a/2,-a/(sqrt(3)*2),c/3];
    r2 = [0,a/sqrt(3),c/3];
    r3 = [-a/2,-a/(sqrt(3)*2),c/3];
end
if system == 6
    r1 = [a,0,0];
    r2 = [0,a,0];
    r3 = [0,0,c];
end
if system == 7
    r1 = [-a/2,a/2,c/2];
    r2 = [a/2,-a/2,c/2];
    r3 = [a/2,a/2,-c/2];
end
if system == 8
    r1 = [a,0,0];
    r2 = [0,b,0];
    r3 = [0,0,c];
end
if system == 9
    r1 = [a,0,0];
    r2 = [0,b/2,-c/2];
    r3 = [0,b/2,c/2];
end
if system == 10
    r1 = [-a/2,b/2,c/2];
    r2 = [a/2,-b/2,c/2];
    r3 = [a/2,b/2,-c/2];
end
if system == 11
    r1 = [0,b/2,c/2];
    r2 = [a/2,0,c/2];
    r3 = [a/2,b/2,0];
end
if system == 12
    r1 = [a,0,0];
    r2 = [0,b,0];
    r3 = [c*cosd(beta),0,c*sind(beta)];
end
if system == 13
    r1 = [a/2,-b/2,0];
    r2 = [a/2,b/2,0];
    r3 = [c*cosd(beta),0,c*sind(beta)];
end
if system == 14
    r1 = [a,0,0];
    r2 = [b*cosd(gamma),b*sind(gamma),0];
    c_x = c*cosd(beta);
    c_y = c*(cosd(alpha)-cosd(beta)*cosd(gamma))/sind(gamma);
    c_z = sqrt(c^2-c_x^2-c_y^2);
    r3 = [c_x,c_y,c_z];
end
volume = dot(r1,cross(r2,r3));
g1 = 2*pi*(cross(r2,r3)/volume);
g2 = 2*pi*(cross(r3,r1)/volume);
g3 = 2*pi*(cross(r1,r2)/volume);
end
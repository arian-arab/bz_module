function [sols]=find_gamma_point(g1,g2,g3,point)
G=[g1;g2;g3];
sols=point*inv(G);
sols=round(sols);
sols=sols*G;
end
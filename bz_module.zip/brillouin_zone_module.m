function brillouin_zone_module()
addpath(strcat(pwd,'\files'))

figure()
set(gcf,'Resize','off','name','Brillouin Zone Module','NumberTitle','off','color','w','units','normalized','position',[0.4 0.3 0.2 0.5],'menubar','none','toolbar','none')

r1 = uicontrol('style','text','units','normalized','position',[0.1,0.6,0.4,0.05],'string','','BackgroundColor','w','Fontsize',9);
r2 = uicontrol('style','text','units','normalized','position',[0.1,0.55,0.4,0.05],'string','','BackgroundColor','w','Fontsize',9);
r3 = uicontrol('style','text','units','normalized','position',[0.1,0.5,0.4,0.05],'string','','BackgroundColor','w','Fontsize',9);
g1 = uicontrol('style','edit','units','normalized','position',[0.6,0.6,0.3,0.05],'string','','BackgroundColor','w','Fontsize',9);
g2 = uicontrol('style','edit','units','normalized','position',[0.6,0.55,0.3,0.05],'string','','BackgroundColor','w','Fontsize',9);
g3 = uicontrol('style','edit','units','normalized','position',[0.6,0.5,0.3,0.05],'string','','BackgroundColor','w','Fontsize',9);
uicontrol('style','text','units','normalized','position',[0,0.6,0.1,0.05],'string','r1:','BackgroundColor','w','Fontsize',12);
uicontrol('style','text','units','normalized','position',[0,0.55,0.1,0.05],'string','r2:','BackgroundColor','w','Fontsize',12);
uicontrol('style','text','units','normalized','position',[0,0.5,0.1,0.05],'string','r3:','BackgroundColor','w','Fontsize',12);
uicontrol('style','text','units','normalized','position',[0.5,0.6,0.1,0.05],'string','g1:','BackgroundColor','w','Fontsize',12);
uicontrol('style','text','units','normalized','position',[0.5,0.55,0.1,0.05],'string','g2:','BackgroundColor','w','Fontsize',12);
uicontrol('style','text','units','normalized','position',[0.5,0.5,0.1,0.05],'string','g3:','BackgroundColor','w','Fontsize',12);

uicontrol('style','text','units','normalized','position',[0,0.65,0.3,0.05],'string','Volume:','BackgroundColor','w','Fontsize',12);
volume = uicontrol('style','text','units','normalized','position',[0.3,0.65,0.3,0.05],'string','Volume','BackgroundColor','w','Fontsize',12);

a = uicontrol('style','edit','units','normalized','position',[0.3,0.85,0.2,0.05],'string','1','BackgroundColor','w','Fontsize',12,'callback',@a_callback);
b = uicontrol('style','edit','units','normalized','position',[0.3,0.8,0.2,0.05],'string','1','BackgroundColor','w','Fontsize',12,'callback',@b_callback);
c = uicontrol('style','edit','units','normalized','position',[0.3,0.75,0.2,0.05],'string','1','BackgroundColor','w','Fontsize',12,'callback',@c_callback);
uicontrol('style','text','units','normalized','position',[0,0.85,0.1,0.05],'string','a:','BackgroundColor','w','Fontsize',12);
uicontrol('style','text','units','normalized','position',[0,0.8,0.1,0.05],'string','b:','BackgroundColor','w','Fontsize',12);
uicontrol('style','text','units','normalized','position',[0,0.75,0.1,0.05],'string','c:','BackgroundColor','w','Fontsize',12);

alpha = uicontrol('style','edit','units','normalized','position',[0.8,0.85,0.2,0.05],'string','90','BackgroundColor','w','Fontsize',12,'callback',@alpha_callback);
beta = uicontrol('style','edit','units','normalized','position',[0.8,0.8,0.2,0.05],'string','90','BackgroundColor','w','Fontsize',12,'callback',@beta_callback);
gamma = uicontrol('style','edit','units','normalized','position',[0.8,0.75,0.2,0.05],'string','90','BackgroundColor','w','Fontsize',12,'callback',@gamma_callback);

uicontrol('style','text','units','normalized','position',[0.5,0.85,0.2,0.05],'string','alpha:','BackgroundColor','w','Fontsize',12);
uicontrol('style','text','units','normalized','position',[0.5,0.8,0.2,0.05],'string','beta:','BackgroundColor','w','Fontsize',12);
uicontrol('style','text','units','normalized','position',[0.5,0.75,0.2,0.05],'string','gamma:','BackgroundColor','w','Fontsize',12);

material = uicontrol('style','text','units','normalized','position',[0,0.42,1,0.05],'string','','BackgroundColor','w','Fontsize',12);


crystal_structures = {'simple cubic','body-centered cubic','face-centered cubic','hexagonal','rhombohedral','simple tetragonal','body-centered tetragonal','simple orthorhombic','base-centered orthorhombic','body-centered orthorhombic','face-centered orthorhombic','simple monoclinic','base-centered monoclinic','triclinic'};
system_popupmenu = uicontrol('style','popupmenu','units','normalized','position',[0.2,0.95,0.6,0.05],'string',crystal_structures,'fontsize',12,'callback',@system_callback);
system = 1;
system_callback()
uicontrol('style','pushbutton','units','normalized','position',[0.2,0.05,0.6,0.05],'string','Plot k-Path','BackgroundColor','g','Fontsize',12,'callback',{@plot_kpath_callback});

    function plot_kpath_callback(~,~,~)
        g1_str = g1.String;
        g2_str = g2.String;
        g3_str = g3.String;
        g1_str = strsplit(g1_str,',');
        if isempty(g1_str{1})~=1
            for i = 1:3
                g1_v(i) = round(str2double(g1_str{i}),3);
            end
            g2_str = strsplit(g2_str,',');
            for i = 1:3
                g2_v(i) = round(str2double(g2_str{i}),3);
            end
            g3_str = strsplit(g3_str,',');
            for i = 1:3
                g3_v(i) = round(str2double(g3_str{i}),3);
            end
            plot_kPath(g1_v,g2_v,g3_v)
        else
            msgbox('You need to first input g1,g2 and g3 vecotrs')
        end
    end

    function system_callback(~,~,~)
        value = system_popupmenu.Value;
        system = value; 
        if system == 1
            a.Enable = 'on';b.Enable = 'off';c.Enable = 'off';alpha.Enable = 'off';beta.Enable = 'off';gamma.Enable = 'off';
            a.String = '4.487';
            material.String = 'FeSi';
        end
        if system == 2
            a.Enable = 'on';b.Enable = 'off';c.Enable = 'off';alpha.Enable = 'off';beta.Enable = 'off';gamma.Enable = 'off';
            a.String = '8.430';
            material.String = 'Ga4Ni';
        end
        if system == 3
            a.Enable = 'on';b.Enable = 'off';c.Enable = 'off';alpha.Enable = 'off';beta.Enable = 'off';gamma.Enable = 'off';
            a.String = '7.710';
            material.String = 'F6KP';
        end
        if system == 4
            a.Enable = 'on';b.Enable = 'off';c.Enable = 'on';alpha.Enable = 'off';beta.Enable = 'off';gamma.Enable = 'off';
            a.String = '6.430';c.String = '17.880';
            material.String = 'Al2S3';
        end        
        if system == 5
            a.Enable = 'on';b.Enable = 'off';c.Enable = 'on';alpha.Enable = 'off';beta.Enable = 'off';gamma.Enable = 'off';
            a.String = '5.142';c.String = '14.308';
            material.String = 'Ti3O';
        end
        if system == 6
            a.Enable = 'on';b.Enable = 'off';c.Enable = 'on';alpha.Enable = 'off';beta.Enable = 'off';gamma.Enable = 'off';
            a.String = '2.8';c.String = '3.67';
            material.String = 'CuAu';
        end 
        if system == 7
            a.Enable = 'on';b.Enable = 'off';c.Enable = 'on';alpha.Enable = 'off';beta.Enable = 'off';gamma.Enable = 'off';
            a.String = '5.55';c.String = '10.3';
            material.String = 'CdAl2S4';
        end        
        if system == 8
            a.Enable = 'on';b.Enable = 'on';c.Enable = 'on';alpha.Enable = 'off';beta.Enable = 'off';gamma.Enable = 'off';
            a.String = '5.62';b.String = '5.67';c.String = '9.05';
            material.String = 'AlPS4';
        end
        if system == 9
            a.Enable = 'on';b.Enable = 'on';c.Enable = 'on';alpha.Enable = 'off';beta.Enable = 'off';gamma.Enable = 'off';
            a.String = '7.008';b.String = '7.008';c.String = '7.006';
            material.String = 'AlPO4';
        end  
        if system == 10
            a.Enable = 'on';b.Enable = 'on';c.Enable = 'on';alpha.Enable = 'off';beta.Enable = 'off';gamma.Enable = 'off';
            a.String = '5.4';b.String = '6.25';c.String = '10.83';
            material.String = 'NaFeS2';
        end    
        if system == 11
            a.Enable = 'on';b.Enable = 'on';c.Enable = 'on';alpha.Enable = 'off';beta.Enable = 'off';gamma.Enable = 'off';
            a.String = '5.540';b.String = '5.487';c.String = '5.195';
            material.String = 'FeS';
        end 
        if system == 12
            a.Enable = 'on';b.Enable = 'on';c.Enable = 'on';alpha.Enable = 'off';beta.Enable = 'on';gamma.Enable = 'off';
            a.String = '3.10';b.String = '7.513';c.String = '4.760';beta.String = '92.710';
            material.String = 'Te';
        end
        if system == 13
            a.Enable = 'on';b.Enable = 'on';c.Enable = 'on';alpha.Enable = 'off';beta.Enable = 'on';gamma.Enable = 'off';
            a.String = '14.735';b.String = '3.642';c.String = '9.375';beta.String = '110.412';
            material.String = 'NbTe2';
        end
        if system == 14
            a.Enable = 'on';b.Enable = 'on';c.Enable = 'on';alpha.Enable = 'on';beta.Enable = 'on';gamma.Enable = 'on';
            a.String = '5.424';b.String = '5.666';c.String = '9.676';alpha.String = '72.976';beta.String = '87.079';gamma.String = '79.975';
            material.String = 'TaTi';
        end
        a_val = str2double(a.String);
        b_val = str2double(b.String);
        c_val = str2double(c.String);
        alpha_val = str2double(alpha.String);
        beta_val = str2double(beta.String);
        gamma_val = str2double(gamma.String);
        [r1_val,r2_val,r3_val,volume_val,g1_val,g2_val,g3_val] = BZ_module_find_g1_g2_g3(a_val,b_val,c_val,alpha_val,beta_val,gamma_val,system);
        r1.String = [num2str(r1_val(1)),',',num2str(r1_val(2)),',',num2str(r1_val(3))];
        r2.String = [num2str(r2_val(1)),',',num2str(r2_val(2)),',',num2str(r2_val(3))];
        r3.String = [num2str(r3_val(1)),',',num2str(r3_val(2)),',',num2str(r3_val(3))];
        g1.String = [num2str(g1_val(1)),',',num2str(g1_val(2)),',',num2str(g1_val(3))];
        g2.String = [num2str(g2_val(1)),',',num2str(g2_val(2)),',',num2str(g2_val(3))];
        g3.String = [num2str(g3_val(1)),',',num2str(g3_val(2)),',',num2str(g3_val(3))];
        volume.String = num2str(volume_val);
    end

    function a_callback(~,~,~)
        a_val = str2double(a.String);
        b_val = str2double(b.String);
        c_val = str2double(c.String);
        alpha_val = str2double(alpha.String);
        beta_val = str2double(beta.String);
        gamma_val = str2double(gamma.String);
        [r1_val,r2_val,r3_val,volume_val,g1_val,g2_val,g3_val] = BZ_module_find_g1_g2_g3(a_val,b_val,c_val,alpha_val,beta_val,gamma_val,system);
        r1.String = [num2str(r1_val(1)),',',num2str(r1_val(2)),',',num2str(r1_val(3))];
        r2.String = [num2str(r2_val(1)),',',num2str(r2_val(2)),',',num2str(r2_val(3))];
        r3.String = [num2str(r3_val(1)),',',num2str(r3_val(2)),',',num2str(r3_val(3))];
        g1.String = [num2str(g1_val(1)),',',num2str(g1_val(2)),',',num2str(g1_val(3))];
        g2.String = [num2str(g2_val(1)),',',num2str(g2_val(2)),',',num2str(g2_val(3))];
        g3.String = [num2str(g3_val(1)),',',num2str(g3_val(2)),',',num2str(g3_val(3))];
        volume.String = num2str(volume_val);
    end

    function b_callback(~,~,~)
        a_val = str2double(a.String);
        b_val = str2double(b.String);
        c_val = str2double(c.String);
        alpha_val = str2double(alpha.String);
        beta_val = str2double(beta.String);
        gamma_val = str2double(gamma.String);
        [r1_val,r2_val,r3_val,volume_val,g1_val,g2_val,g3_val] = BZ_module_find_g1_g2_g3(a_val,b_val,c_val,alpha_val,beta_val,gamma_val,system);
        r1.String = [num2str(r1_val(1)),',',num2str(r1_val(2)),',',num2str(r1_val(3))];
        r2.String = [num2str(r2_val(1)),',',num2str(r2_val(2)),',',num2str(r2_val(3))];
        r3.String = [num2str(r3_val(1)),',',num2str(r3_val(2)),',',num2str(r3_val(3))];
        g1.String = [num2str(g1_val(1)),',',num2str(g1_val(2)),',',num2str(g1_val(3))];
        g2.String = [num2str(g2_val(1)),',',num2str(g2_val(2)),',',num2str(g2_val(3))];
        g3.String = [num2str(g3_val(1)),',',num2str(g3_val(2)),',',num2str(g3_val(3))];
        volume.String = num2str(volume_val);
    end

    function c_callback(~,~,~)
        a_val = str2double(a.String);
        b_val = str2double(b.String);
        c_val = str2double(c.String);
        alpha_val = str2double(alpha.String);
        beta_val = str2double(beta.String);
        gamma_val = str2double(gamma.String);
        [r1_val,r2_val,r3_val,volume_val,g1_val,g2_val,g3_val] = BZ_module_find_g1_g2_g3(a_val,b_val,c_val,alpha_val,beta_val,gamma_val,system);
        r1.String = [num2str(r1_val(1)),',',num2str(r1_val(2)),',',num2str(r1_val(3))];
        r2.String = [num2str(r2_val(1)),',',num2str(r2_val(2)),',',num2str(r2_val(3))];
        r3.String = [num2str(r3_val(1)),',',num2str(r3_val(2)),',',num2str(r3_val(3))];
        g1.String = [num2str(g1_val(1)),',',num2str(g1_val(2)),',',num2str(g1_val(3))];
        g2.String = [num2str(g2_val(1)),',',num2str(g2_val(2)),',',num2str(g2_val(3))];
        g3.String = [num2str(g3_val(1)),',',num2str(g3_val(2)),',',num2str(g3_val(3))];
        volume.String = num2str(volume_val);
    end

 function alpha_callback(~,~,~)
        a_val = str2double(a.String);
        b_val = str2double(b.String);
        c_val = str2double(c.String);
        alpha_val = str2double(alpha.String);
        beta_val = str2double(beta.String);
        gamma_val = str2double(gamma.String);
        [r1_val,r2_val,r3_val,volume_val,g1_val,g2_val,g3_val] = BZ_module_find_g1_g2_g3(a_val,b_val,c_val,alpha_val,beta_val,gamma_val,system);
        r1.String = [num2str(r1_val(1)),',',num2str(r1_val(2)),',',num2str(r1_val(3))];
        r2.String = [num2str(r2_val(1)),',',num2str(r2_val(2)),',',num2str(r2_val(3))];
        r3.String = [num2str(r3_val(1)),',',num2str(r3_val(2)),',',num2str(r3_val(3))];
        g1.String = [num2str(g1_val(1)),',',num2str(g1_val(2)),',',num2str(g1_val(3))];
        g2.String = [num2str(g2_val(1)),',',num2str(g2_val(2)),',',num2str(g2_val(3))];
        g3.String = [num2str(g3_val(1)),',',num2str(g3_val(2)),',',num2str(g3_val(3))];
        volume.String = num2str(volume_val);
 end

 function beta_callback(~,~,~)
        a_val = str2double(a.String);
        b_val = str2double(b.String);
        c_val = str2double(c.String);
        alpha_val = str2double(alpha.String);
        beta_val = str2double(beta.String);
        gamma_val = str2double(gamma.String);
        [r1_val,r2_val,r3_val,volume_val,g1_val,g2_val,g3_val] = BZ_module_find_g1_g2_g3(a_val,b_val,c_val,alpha_val,beta_val,gamma_val,system);
        r1.String = [num2str(r1_val(1)),',',num2str(r1_val(2)),',',num2str(r1_val(3))];
        r2.String = [num2str(r2_val(1)),',',num2str(r2_val(2)),',',num2str(r2_val(3))];
        r3.String = [num2str(r3_val(1)),',',num2str(r3_val(2)),',',num2str(r3_val(3))];
        g1.String = [num2str(g1_val(1)),',',num2str(g1_val(2)),',',num2str(g1_val(3))];
        g2.String = [num2str(g2_val(1)),',',num2str(g2_val(2)),',',num2str(g2_val(3))];
        g3.String = [num2str(g3_val(1)),',',num2str(g3_val(2)),',',num2str(g3_val(3))];
        volume.String = num2str(volume_val);
 end

 function gamma_callback(~,~,~)
        a_val = str2double(a.String);
        b_val = str2double(b.String);
        c_val = str2double(c.String);
        alpha_val = str2double(alpha.String);
        beta_val = str2double(beta.String);
        gamma_val = str2double(gamma.String);
        [r1_val,r2_val,r3_val,volume_val,g1_val,g2_val,g3_val] = BZ_module_find_g1_g2_g3(a_val,b_val,c_val,alpha_val,beta_val,gamma_val,system);
        r1.String = [num2str(r1_val(1)),',',num2str(r1_val(2)),',',num2str(r1_val(3))];
        r2.String = [num2str(r2_val(1)),',',num2str(r2_val(2)),',',num2str(r2_val(3))];
        r3.String = [num2str(r3_val(1)),',',num2str(r3_val(2)),',',num2str(r3_val(3))];
        g1.String = [num2str(g1_val(1)),',',num2str(g1_val(2)),',',num2str(g1_val(3))];
        g2.String = [num2str(g2_val(1)),',',num2str(g2_val(2)),',',num2str(g2_val(3))];
        g3.String = [num2str(g3_val(1)),',',num2str(g3_val(2)),',',num2str(g3_val(3))];
        volume.String = num2str(volume_val);
    end
end
